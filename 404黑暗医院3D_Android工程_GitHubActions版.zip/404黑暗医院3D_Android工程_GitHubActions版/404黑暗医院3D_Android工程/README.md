# 404：黑暗医院 3D — Android 工程

这是一个可导入 Android Studio 的原生 Android/Kotlin 游戏工程。

## 环境
- Android Studio Ladybug / 更高版本
- JDK 17
- Android SDK 35
- Gradle 8.x（Android Studio 可自动配置）

## 编译
1. 解压 ZIP。
2. 用 Android Studio 打开 `404黑暗医院3D_Android工程`。
3. 等待 Gradle Sync。
4. 连接 Android 手机并开启 USB 调试。
5. Run `app`。
6. 生成 APK：Build > Build APK(s)。

默认 APK：
`app/build/outputs/apk/debug/app-debug.apk`

## 操作
- 左下：移动/转向
- 右下：视角/手电
- 右上：奔跑
- 横屏第一人称

## 游戏流程
1. 找护士站病历。
2. 找收音机线索。
3. 在储物柜区域解出 1107。
4. 获得保险丝并修复供电。
5. 找出口钥匙。
6. 躲开追踪怪物并逃生。

说明：当前工程不使用第三方游戏引擎，3D 场景使用 Kotlin 自绘的轻量射线渲染，因此工程体积小、方便继续扩展。


## GitHub Actions 自动编译 APK

本工程已加入 `.github/workflows/build-apk.yml`。

上传到 GitHub 后：
1. 打开仓库的 **Actions**。
2. 选择 **Build Android APK**。
3. 点击 **Run workflow** 手动开始编译；推送到 `main`/`master` 也会自动编译。
4. 编译完成后打开对应的运行记录，在 **Artifacts** 下载 `404-black-hospital-3d-debug-apk`。
5. 解压后得到真正的 `.apk`，可安装到 Android 手机。

该工作流使用 JDK 17、Android SDK 35，并构建 Debug APK。
