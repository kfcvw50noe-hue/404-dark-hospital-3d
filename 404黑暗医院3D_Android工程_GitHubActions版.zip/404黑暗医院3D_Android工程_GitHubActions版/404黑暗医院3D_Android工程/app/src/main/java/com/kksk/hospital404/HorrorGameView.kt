package com.kksk.hospital404

import android.content.Context
import android.graphics.*
import android.os.*
import android.view.*
import kotlin.math.*
import kotlin.random.Random

/**
 * 404：黑暗医院
 * Self-contained prototype: first-person ray-cast renderer,
 * touch controls, multi-stage puzzle, enemy chase, flashlight,
 * sanity, vibration and synthesized audio hooks.
 */
class HorrorGameView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var last = System.nanoTime()
    private var started = false
    private var dead = false
    private var won = false

    private var px = 1.5
    private var py = 16.5
    private var angle = 0.0
    private var battery = 100.0
    private var sanity = 100.0
    private var health = 100.0
    private var hasFuse = false
    private var hasKey = false
    private var codeSolved = false
    private var fuseFixed = false
    private var monsterActive = false
    private var monsterX = 16.5
    private var monsterY = 13.5
    private var eventTimer = 5.0
    private var scareTimer = 0.0
    private var message = "找到护士站的密码线索。"

    private var forward = false
    private var backward = false
    private var turnLeft = false
    private var turnRight = false
    private var sprint = false
    private var flashlight = true

    // 1 = wall, 0 = floor; letters are interactive objects.
    private val map = arrayOf(
        "####################",
        "#......#...........#",
        "#.####.#.#####.###.#",
        "#.#....#.....#...#.#",
        "#.#.########.#.#.#.#",
        "#...#......#.#.#...#",
        "###.#.####.#.#.#####",
        "#...#.#P.#.#.#.....#",
        "#.###.#..#.#.#####.#",
        "#.....#..#.#.....#.#",
        "#####.##.#.#####.#.#",
        "#...#....#.....#.#.#",
        "#.#.#.#########.#..#",
        "#.#.#...........###",
        "#.#.#############K#",
        "#S.................#",
        "####################"
    )

    private val fov = Math.PI / 3.0
    private val touchMap = HashMap<Int, PointF>()
    private var joystickId = -1
    private var lookId = -1
    private var joyX = 0f
    private var joyY = 0f
    private var lookX = 0f

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val now = System.nanoTime()
        val dt = min(0.05, (now - last) / 1e9)
        last = now
        update(dt)
        render(c)
        postInvalidateOnAnimation()
    }

    private fun wall(x: Double, y: Double): Boolean {
        val gx = floor(x).toInt()
        val gy = floor(y).toInt()
        if (gx < 0 || gy < 0 || gy >= map.size || gx >= map[0].length) return true
        return map[gy][gx] == '#'
    }

    private fun move(dx: Double, dy: Double) {
        if (!wall(px + dx, py) && !wall(px + dx, py + .16) && !wall(px + dx, py - .16)) px += dx
        if (!wall(px, py + dy) && !wall(px + .16, py + dy) && !wall(px - .16, py + dy)) py += dy
    }

    private fun distance(ax: Double, ay: Double, bx: Double, by: Double) =
        hypot(ax - bx, ay - by)

    private fun update(dt: Double) {
        if (!started || dead || won) return

        val speed = if (sprint) 2.4 else 1.25
        val move = speed * dt
        if (forward) { move(cos(angle) * move, sin(angle) * move) }
        if (backward) { move(-cos(angle) * move, -sin(angle) * move) }
        if (turnLeft) angle -= 1.9 * dt
        if (turnRight) angle += 1.9 * dt
        if (lookX != 0f) {
            angle += lookX * 1.8 * dt
            lookX = 0f
        }

        if (flashlight) battery -= dt * if (sprint) .45 else .12
        if (battery <= 0) { battery = 0.0; flashlight = false }

        eventTimer -= dt
        scareTimer = max(0.0, scareTimer - dt)

        // Puzzle progression:
        // Nurse station area -> random-looking clue message -> keypad zone -> fuse -> exit.
        if (!codeSolved && px > 5 && px < 8 && py < 5) {
            message = "墙上的病历写着：护士生日 = 11 / 07。"
        }
        if (!codeSolved && px > 12 && px < 15 && py > 3 && py < 7) {
            message = "收音机重复播放：1107……1107……"
        }
        if (!codeSolved && px > 8 && px < 11 && py > 7 && py < 10) {
            codeSolved = true
            message = "密码正确。储物柜弹开了——里面有一根保险丝。"
            hasFuse = true
            vibrate(80)
        }
        if (hasFuse && !fuseFixed && px > 13 && py > 10) {
            fuseFixed = true
            message = "保险丝装好了。出口门通电。"
            vibrate(120)
        }
        if (fuseFixed && !hasKey && px > 15 && py > 13) {
            hasKey = true
            message = "你拿到了出口钥匙。身后突然安静了。"
            monsterActive = true
        }
        if (hasKey && px > 16 && py < 3) {
            won = true
            message = "门开了……门外还是这家医院。"
        }

        if (!monsterActive && distance(px, py, monsterX, monsterY) < 7) {
            monsterActive = true
            message = "你听见了奔跑声。它终于找到你了。"
            vibrate(200)
        }
        if (monsterActive) {
            val a = atan2(py - monsterY, px - monsterX)
            val ms = (.45 + if (sprint) .10 else 0.0) * dt
            monsterX += cos(a) * ms
            monsterY += sin(a) * ms
            val d = distance(px, py, monsterX, monsterY)
            if (d < 1.0 && scareTimer <= 0) {
                health -= 35
                sanity -= 25
                scareTimer = 3.0
                vibrate(500)
                message = "它就在你身后。"
            }
            if (d < 4) sanity -= dt * 5
        }

        if (eventTimer <= 0) {
            eventTimer = 6 + Random.nextDouble() * 8
            if (Random.nextBoolean()) {
                message = listOf(
                    "走廊尽头刚才有人站着。",
                    "不要回头。",
                    "有人在你耳边呼吸。",
                    "病房里的床动了一下。",
                    "你确定刚才只有一个影子吗？"
                ).random()
                sanity -= 5
                vibrate(40)
            }
        }

        if (sanity <= 0 || health <= 0) dead = true
    }

    private fun render(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(Color.BLACK)

        val sky = Paint().apply { shader = LinearGradient(0f, 0f, 0f, h / 2,
            Color.rgb(14, 18, 21), Color.rgb(2, 3, 4), Shader.TileMode.CLAMP) }
        c.drawRect(0f, 0f, w, h, sky)

        val rays = min(420, width)
        val stripe = w / rays
        for (i in 0 until rays) {
            val ra = angle - fov / 2 + (i.toDouble() / rays) * fov
            val rx = cos(ra)
            val ry = sin(ra)
            var d = 0.0
            while (d < 18 && !wall(px + rx * d, py + ry * d)) d += .025
            val corrected = d * cos(ra - angle)
            val wallH = min(h * 2, h / (corrected + .001))
            val shade = max(0.0, 1.0 - corrected / 13.0)
            val col = (28 * shade).toInt().coerceIn(0, 35)
            paint.color = Color.rgb(col, col + 3, col + 5)
            c.drawRect(i * stripe, (h - wallH.toFloat()) / 2,
                (i + 1) * stripe + 1, (h + wallH.toFloat()) / 2, paint)
        }

        // flashlight cone
        if (flashlight) {
            val radial = RadialGradient(w/2, h*.53f, min(w,h)*.52f,
                intArrayOf(Color.argb(65,220,230,235), Color.argb(0,0,0,0)),
                floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
            paint.shader = radial
            c.drawRect(0f,0f,w,h,paint)
            paint.shader = null
        }

        // enemy
        if (monsterActive) {
            val dx = monsterX - px
            val dy = monsterY - py
            val d = hypot(dx, dy)
            var a = atan2(dy, dx) - angle
            while (a > Math.PI) a -= 2*Math.PI
            while (a < -Math.PI) a += 2*Math.PI
            if (abs(a) < fov * .7) {
                val sx = w/2 + (a/fov*w)
                val sz = min(h*1.2, h/(d+.2))
                paint.color = Color.rgb(4,4,4)
                c.drawOval(sx.toFloat()-sz.toFloat()*.18f, h/2-sz.toFloat()*.42f,
                    sx.toFloat()+sz.toFloat()*.18f, h/2+sz.toFloat()*.42f, paint)
                paint.color = Color.WHITE
                c.drawCircle(sx.toFloat()-sz.toFloat()*.055f, h*.47f, max(2f,sz.toFloat()*.025f),paint)
                c.drawCircle(sx.toFloat()+sz.toFloat()*.055f, h*.47f, max(2f,sz.toFloat()*.025f),paint)
            }
        }

        // HUD
        paint.shader = null
        paint.color = Color.WHITE
        paint.textSize = 26f
        c.drawText("404号病房  03:17 AM", 18f, 34f, paint)
        paint.textSize = 18f
        c.drawText("🔋 ${battery.toInt()}%   ❤ ${health.toInt()}   🧠 ${sanity.toInt()}%", 18f, 60f, paint)
        paint.textSize = 20f
        c.drawText(message, 18f, h - 38f, paint)

        if (!started) {
            overlay(c, "404：黑暗医院", "触摸屏幕开始\\n找到密码、保险丝和出口钥匙。")
        } else if (dead) {
            overlay(c, "你死了", "医院里传来你的声音：\\n“别回头。”\\n\\n重新打开游戏再试一次。")
        } else if (won) {
            overlay(c, "门开了", "你逃出了这间病房。\\n但你发现门外还是404号病房。")
        }

        if (started && !dead && !won) drawControls(c)
    }

    private fun overlay(c: Canvas, title: String, sub: String) {
        paint.color = Color.argb(235, 0,0,0)
        c.drawRect(0f,0f,width.toFloat(),height.toFloat(),paint)
        paint.color = Color.WHITE
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 42f
        c.drawText(title,width/2f,height*.42f,paint)
        paint.textSize = 20f
        sub.split("\\n").forEachIndexed { i,s ->
            c.drawText(s,width/2f,height*.50f+i*30f,paint)
        }
        paint.textAlign = Paint.Align.LEFT
    }

    private fun drawControls(c: Canvas) {
        paint.color = Color.argb(90,255,255,255)
        c.drawCircle(95f,height-105f,58f,paint)
        paint.color = Color.argb(170,255,255,255)
        c.drawCircle(95f,height-105f,24f,paint)
        paint.color = Color.argb(100,255,255,255)
        c.drawCircle(width-100f,height-105f,62f,paint)
        paint.color = Color.WHITE
        paint.textSize = 16f
        c.drawText("移动",65f,height-100f,paint)
        c.drawText(if(flashlight)"手电" else "手电关",width-125f,height-100f,paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x=e.x; val y=e.y
        when(e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!started) { started=true; vibrate(60); return true }
                if (dead || won) return true
                val id=e.getPointerId(e.actionIndex)
                if (x < width*.38f && y > height*.62f) {
                    joystickId=id; updateJoy(x,y)
                } else if (x > width*.68f && y > height*.62f) {
                    lookId=id
                    lookX=if(x>width*.82f) 1f else -1f
                    if(y > height*.82f) flashlight=!flashlight
                } else if (x > width*.82f && y < height*.35f) {
                    sprint=true
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for(i in 0 until e.pointerCount) {
                    val id=e.getPointerId(i)
                    if(id==joystickId) updateJoy(e.getX(i),e.getY(i))
                    if(id==lookId) lookX=if(e.getX(i)>width*.68f) 1f else -1f
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val id=e.getPointerId(e.actionIndex)
                if(id==joystickId){joystickId=-1;forward=false;backward=false}
                if(id==lookId){lookId=-1;lookX=0f}
                sprint=false
            }
        }
        return true
    }

    private fun updateJoy(x:Float,y:Float) {
        val cx=95f; val cy=height-105f
        val dx=x-cx; val dy=y-cy
        forward=dy < -18; backward=dy > 18
        turnLeft=dx < -28; turnRight=dx > 28
    }

    private fun vibrate(ms: Long) {
        try {
            val v = context.getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }
}
